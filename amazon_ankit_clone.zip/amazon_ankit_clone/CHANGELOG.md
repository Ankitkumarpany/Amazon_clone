# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### 0.1.1 (2021-01-24)


### Features

* add standard-version ([54c1e6a](https://github.com/diogojorgebasso/amazon/commit/54c1e6a3564aad336b26985e7a5e979dac36add2))


### Bug Fixes

* typo's in the functions ([7d2b6ff](https://github.com/diogojorgebasso/amazon/commit/7d2b6ff86ef56c8aef7639005aed1e24094eebaf))
