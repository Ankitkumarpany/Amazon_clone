# Getting Started with Amazon Clone

> In the past week, I worked in creating an amazon UI and **working** clone!

Available live here: https://ecommerce-7abf9.web.app/

## Technologies and Stacks used

This project was bootstrapped with [React App](https://github.com/facebook/create-react-app).
This project is hosted in [Firebase](https://firebase.google.com/)
Inspired by [Clever Programer](https://github.com/CleverProgrammers)

## LICENSE

[By Apache v.2](LICENSE)
